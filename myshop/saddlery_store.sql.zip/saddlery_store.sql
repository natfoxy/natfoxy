-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 22, 2021 at 01:31 PM
-- Server version: 8.0.25-0ubuntu0.20.04.1
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saddlery_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int UNSIGNED NOT NULL,
  `discount_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `discount_id`, `user_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cart_user`
--

CREATE TABLE `cart_user` (
  `id` int UNSIGNED NOT NULL,
  `product_id` int UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `quantity` double NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cart_user`
--

INSERT INTO `cart_user` (`id`, `product_id`, `user_id`, `quantity`, `date_added`, `date_modified`) VALUES
(1, 2, 1, 2, '2021-06-22 08:41:54', '2021-06-22 07:41:54'),
(2, 5, 1, 1, '2021-06-22 08:55:10', '2021-06-22 07:55:10'),
(3, 3, 1, 1, '2021-06-22 12:57:22', '2021-06-22 11:57:22');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `date_added`, `date_modified`) VALUES
(1, 'Bates', 'Lovely, quality saddles', '2021-06-19 10:28:25', '2021-06-19 09:28:25'),
(2, 'Albion', 'Comfortable and durable saddles', '2021-06-19 10:32:15', '2021-06-19 09:32:15'),
(3, 'Crosby', 'Well priced saddles for all levels', '2021-06-19 10:32:15', '2021-06-19 09:32:15');

-- --------------------------------------------------------

--
-- Table structure for table `discount_codes`
--

CREATE TABLE `discount_codes` (
  `id` int UNSIGNED NOT NULL,
  `discount_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `amount` int NOT NULL,
  `amount_percent` tinyint(1) NOT NULL DEFAULT '0',
  `amount_decimal` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `discount_codes`
--

INSERT INTO `discount_codes` (`id`, `discount_code`, `amount`, `amount_percent`, `amount_decimal`) VALUES
(1, 'BADMINTON10', 10, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(250) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int UNSIGNED NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `image`, `price`, `category_id`, `date_added`, `date_modified`) VALUES
(1, 'Bates Innova Mono+ Dressage Saddle', '\r\nInnova Mono+\r\nExperience the ultra-close contact of the new Innova Mono+ from Bates Saddles, presented in luxurious opulence leather, renowned for its ultra-soft, natural and grippy characteristics.\r\n \r\nThe Innova Mono+ features a deep, open seat that works in partnership with the new revolutionary FlexiContourbloc®, which is not only anatomically contoured to the rider’s leg but adjustable too. The innovative new mono flap design ensures unrivalled close contact, connection and rider customisation by utilising the benefits of the FlexiContourbloc® and Adjustable Ergonomic Stirrup Bar. Take your Dressage to the highest level in the new Bates Innova Mono+ \r\n \r\nThe Innova Mono+ features new, luxurious Opulence leather which is ultra-soft, very grippy and has a natural finish. Immediately comfortable requiring no breaking in time in the saddle.\r\n \r\nThe innovative, new mono flap design ensures unrivaled close contact and connection.\r\n \r\n*Also available in Luxe Leather by special order*\r\n', 'n_11346_1.jpg', '2699.00', 1, '2021-06-19 09:38:40', '2021-06-19 08:38:40'),
(2, 'Albion Platinum Ultima ', 'Albion Platinum Ultima\r\n\r\nThe Platinum Ultima is a truly unique saddle offering the ultimate fitting solution without compromise to the horse or rider. The Platinum comes with an interchangeable tree and switch panel system, which can only be changed by an approved Albion stockists. It has specially tanned full grain Ultima flap leather and the best Italian calfskins for seat and pads, with moulded knee rolls. Available in standard seat or narrow seat.\r\n', 'n_11033_3.jpg', '2480.00', 2, '2021-06-19 10:33:26', '2021-06-19 09:33:26'),
(3, 'Albion Fabrento Dressage Saddle', 'Albion Fabrento Dressage Saddle\r\n\r\nDesigned for modern dressage competition and sports horses the Albion Fabrento is a beautifully styled, quality, mono-flap saddle with serious performance potential. After careful bio-mechanical study of horse and rider the Fabrento places the rider in the perfect position to apply all aids effectively from a secure central position. The tapered knee roll provides support without restriction and is particularly useful for riders with long legs riding shorter backed horses. \r\n\r\nThe Albion Fabrento is built on an all new Adjusta-Tree with a more open head and lower profile suiting higher, longer withered horses and the width can be adjusted by a trained saddle fitter to suit each individual. This unique, ergonomic tree is ideal for the modern sports horse and ensures maximum should rotation whilst reducing loin pressure, allowing a greater freedom of movement\r\nFeatures\r\n\r\n    British made and designed\r\n    All new adjustable tree\r\n    Short back panels\r\n    Wool flocked\r\n    Calfskin finish\r\n\r\n', 'n_12016_1.jpg', '2890.00', 2, '2021-06-19 10:36:18', '2021-06-19 09:36:18'),
(4, 'Bates Advanta Event Saddle', 'Bates Advanta Event Saddle\r\nThe Bates Advanta® eventing saddle is engineered for perfect connection between you and your horse.\r\nWith an ultra-sensitive feel of your horse and effortless balance, together you are poised for take-off and prepared for the unexpected. Sharpen your reflexes and push your boundaries in the new competitive advantage.\r\n\r\nEngineered for competitive ADVANTAge\r\n\r\n    Adjustable Ergonomic Stirrup Bar\r\n    EASY-CHANGE® Fit Solution\r\n    Wither Freedom\r\n    Forward cut mono flap\r\n    SynergyPanel™\r\n    Streamlined girth points\r\n    SweetSpot\r\n    CAIR® Cushion System\r\n    Recessed stirrup channel\r\n    FlexiContourbloc\r\n    Grippy reinforcement\r\n\r\n', 'n_12528_1.jpg', '2699.00', 1, '2021-06-19 10:37:01', '2021-06-19 09:37:01'),
(5, 'Bates Momentum Saddle (Cair®)', '\r\n\r\nThe Bates Momentum Saddle is the ultimate performance tool for serious eventers, the Bates Momentum delivers a seamless transition from your seat along your inner thigh for immediate contact with the horse.\r\n\r\nThe forward cut flap and a low, narrow waist enable the rider to sit into, rather than onto the saddle, so you won’t get left behind.\r\n\r\n    A forward cut event saddle designed for pure performance\r\n    Delivers unprecedented balance, maximumk control and instantaneous comfort\r\n    A seamless transition from your seat along your inner thigh offers immediate contact\r\n    Maximises freedom of movement and comfort for your horse\r\n    Features include short girth points, Ergonmic Stirrup Bar and Floexibloc® system\r\n\r\n', 'n_8076_2.jpg', '1899.00', 1, '2021-06-19 10:37:59', '2021-06-19 09:37:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `date_added`, `date_modified`) VALUES
(1, 'Nat', '2021-06-21 13:30:35', '2021-06-21 12:30:35');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_user`
--
ALTER TABLE `cart_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_codes`
--
ALTER TABLE `discount_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart_user`
--
ALTER TABLE `cart_user`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `discount_codes`
--
ALTER TABLE `discount_codes`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
